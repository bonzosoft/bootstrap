function Invoke-GitCommand {
    [CmdletBinding()]
    [OutputType()]

    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [scriptblock]$ScriptBlock
    )

    begin {

    }

    process {
        try {

        }
        finally {
            
        }
    }

    end {

    }
}