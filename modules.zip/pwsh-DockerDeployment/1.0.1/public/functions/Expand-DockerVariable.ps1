function Expand-DockerVariable {
    [CmdletBinding()]
    [OutputType([string])]

    param (
        [Parameter(Mandatory)]
        [AllowEmptyString()]
        [string]$Content
    )

    begin {

    }

    process {
        if (-not ($Content.Trim() -like "^#")) {
            $Content = $Content.Replace('[[PROJECTNAME]]',        $Script:Context.ProjectName)
            $Content = $Content.Replace('[[HOSTNAME]]',           $Script:Context.Hostname)
            $Content = $Content.Replace('[[DOMAIN]]',             $Script:Context.Domain)
            $Content = $Content.Replace('[[STACKDIR]]',           $Script:Context.StackDir.FullName)
            $Content = $Content.Replace('[[CONFIGDIR]]',          $Script:Context.StateDir.FullName)
            if ($Script:Context.StorageDir -like "^nfs://*") {
                $Content = $Content.Replace('[[VOL_DRIVER]]',  'local')
                $Content = $Content.Replace('([[VOL_TYPE]]', 'nfs')
                $Content = $Content.Replace('[[VOL_DEVICE]]', ":" + $(($Script:Context.StorageDir.FullName) -split ":")[1])
                $Content = $Content.Replace('[[VOL_OPTIONS]]', "addr=" + $(($Script:Context.StorageDir.FullName) -split ":")[0] + ",rw,nolock,hard,nointr,nfsvers=4")
            }
            else {
                $Content = $Content.Replace('[[DATADIR]]',            $Script:Context.StorageDir.FullName)
            }
            $Content = $Content.Replace('[[PUID]]',               $Script:Context.DefaultPUID)
            $Content = $Content.Replace('[[PGID]]',               $Script:Context.DefaultPGID)
            $Content = $Content.Replace('[[SOCKETPGID]]',         $Script:Context.SocketPGIDGID)
            $Content = $Content.Replace('[[ADMIN_NAME]]',         $Script:Context.Tenant.Admin.Name)
            $Content = $Content.Replace('[[ADMIN_EMAIL]]',        $Script:Context.Tenant.Admin.Email)
            $Content = $Content.Replace('[[ADMIN_PASS]]',         (ConvertFrom-SecureString -SecureString $Script:Context.Tenant.Admin.Password -AsPlainText))
            $Content = $Content.Replace('[[SMTP_RELAY_HOST]]',    $Script:Context.Tenant.SmtpRelay.Host)
            $Content = $Content.Replace('[[SMTP_RELAY_PORT]]',    $Script:Context.Tenant.SmtpRelay.Port)
            $Content = $Content.Replace('[[SMTP_RELAY_USER]]',    $Script:Context.Tenant.SmtpRelay.Name)
            $Content = $Content.Replace('[[SMTP_RELAY_PASS]]',    (ConvertFrom-SecureString -SecureString $Script:Context.Tenant.SmtpRelay.Password -AsPlainText))
            $Content = $Content.Replace('[[SMTP_PROVIDER_HOST]]', $Script:Context.Tenant.SmtpProvider.Host)
            $Content = $Content.Replace('[[SMTP_PROVIDER_PORT]]', $Script:Context.Tenant.SmtpProvider.Port)
            $Content = $Content.Replace('[[SMTP_PROVIDER_USER]]', $Script:Context.Tenant.SmtpProvider.Name)
            $Content = $Content.Replace('[[SMTP_PROVIDER_PASS]]', (ConvertFrom-SecureString -SecureString $Script:Context.Tenant.SmtpProvider.Password -AsPlainText))            
        }
    }

    end {
        Write-Output $Content
    }
}