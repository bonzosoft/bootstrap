function Get-Argon2Key {

    [CmdletBinding()]
    [OutputType([pscustomobject], [string], [string])]
    param(
        [Parameter(Mandatory)]
        [SecureString]$Password,

        [Parameter(Mandatory, ParameterSetName = "SaltLength")]
        [ValidateRange(16,32)]
        [int]$SaltLength = 16,

        [Parameter()]
        [byte[]]$Salt = [Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(16)),

        [Parameter()]
        [ValidateSet(16, 24, 32)]
        [int]$Length = 32,

        [ValidateRange(1,10)]
        [int]$Iterations = 3,

        [ValidateRange(12,24)]
        [int]$Memory = 18, # 2^18 KiB = 256 MiB

        [ValidateRange(1,32)]
        [int]$Parallelism = 1,

        [Parameter()]
        [ValidateSet(10, 13)]
        $Version = 13,

        [switch]$AsPlainText,
        [switch]$AsBase64
    )


    process {
        $params = @(
            $Salt
            "-id"
            "-t", $Iterations
            "-m", $Memory
            "-p", $Parallelism
            "-l", $Length
            "-v", $Version
            "-e"
        )
        $output = ConvertFrom-SecureString -SecureString $Password -AsPlainText | argon2 @params 2> Variable:errStream
        if ($LASTEXITCODE -ne 0) {
            throw ($errStream -join [Environment]::NewLine)
        }

        #
        # Formato:
        # $argon2id$v=19$m=262144,t=3,p=1$BASE64_SALT$BASE64_HASH
        #
        $parts = $output -split '\$'
        if ($parts.Count -lt 6) {
            throw "Salida inesperada de argon2: $output"
        }
        $hashBase64 = ($output -split '\$')[-1]
        if ($Base64.IsPresent) {
            return $hashBase64
        }
        else {
            return [Convert]::FromBase64String($hashBase64)
        }
    }
}


$salt = [Security.Cryptography.RandomNumberGenerator]::GetBytes(16)
$key = Get-Argon2Key -Password $Password -Salt $salt
$saltBase64 = [Convert]::ToBase64String($salt)
$salt = [Convert]::FromBase64String($json.salt)
try {
    # ConvertFrom-SecureString / ConvertTo-SecureString
}
finally {
    [System.Security.Cryptography.CryptographicOperations]::ZeroMemory($key)
}