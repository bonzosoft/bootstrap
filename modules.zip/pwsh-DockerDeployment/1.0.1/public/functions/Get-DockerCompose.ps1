function Get-DockerCompose {
    [CmdletBinding()]
    [OutputType([PSCustomObject])]

    param (
        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [IO.FileInfo]$Path = $Script:Context.MainStackFile
    )

    begin {
        [string[]]$lines = @()
        [string[]]$errorMessage = @()
    }

    end {
        if (-not (Test-Path -Path $Path.FullName)) {
            throw "File '$($Path.FullName)' not found."
        }
        
        #$lines = docker compose -f $Path.FullName config 2> variable:errorMessage
        $lines = docker compose config 2> variable:errorMessage
            #--no-consistency		Don't check model consistency - warning: may produce invalid Compose output
            #--no-env-resolution	Don't resolve service env files
            #--no-interpolate		Don't interpolate environment variables
            #--no-normalize		    Don't normalize compose model (convierte formatos cortos a largos)
            #--no-path-resolution	Don't resolve file paths
        if ($LASTEXITCODE) {
            throw "Unable to parse '$($Path.FullName)': $errorMessage"
        }
        if ($errorMessage) {
            Write-Warning -Message ($errorMessage | Out-String)
        }

        Write-Output -InputObject ($lines | ConvertFrom-Yaml)
    }
}
