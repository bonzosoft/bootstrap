function Get-DockerContext {
    [CmdletBinding()]
    [OutputType([hashtable])]

    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [IO.DirectoryInfo]$Path
    )

    begin {
        [hashtable]$context = [ordered]@{}
    }

    process {
        <# folder structure
    /mnt/tank0/apps/
    |- stack/ <==================================================== $BaseDir
    |  | - .config/
    |  |  |- github-cli/
    |  |  |- git-cli/
    |  |  |- bitwarden-cli/
    |  |  |- config.json
    |  |
    |  |- common/
    |  |
    |  |- <service-name>/ <=========================================== $Path
    |     |- include/
    |     |- config/
    |     |- .env
    |     |- compose.yaml
    |     |- onpull.ps1
    |
    |- state/
    |  |- <service-name>/
    |     |- .secrets/
    |     |- app/
    |     |- db/
    |     |- cache/
    
    /mnt/tank1/apps/
    |- storage/
    |  |- <service-name>/
    |  |  | - app
        #>
        # names
        $context.ProjectName   = [string]$Path.BaseName
        $context.Hostname      = [string](Get-Content "/host/etc/hostname")
        # directories
        $context.BaseDir       = [IO.DirectoryInfo]$Path.Parent
        # root directory leafs
        $context.CommonDir     = [IO.DirectoryInfo](Join-Path -Path $context.BaseDir -ChildPath @("common"))
        $context.ConfigDir     = [IO.DirectoryInfo](Join-Path -Path $context.BaseDir -ChildPath @(".config"))
        $context.StackDir      = [IO.DirectoryInfo](Join-Path -Path $context.BaseDir -ChildPath @($context.ProjectName))
        $context.StateDir      = [IO.DirectoryInfo](Join-Path -Path $context.BaseDir.Parent -ChildPath @("state", $context.ProjectName))
        $context.StorageDir    = [IO.DirectoryInfo](Join-Path -Path $context.BaseDir.Parent -ChildPath @("storage", $context.ProjectName))
        # config files leafs
        $context.ConfigFile    = [IO.FileInfo](Join-Path -Path $context.ConfigDir -ChildPath @("env.json"))
        $context.GHConfigDir   = [IO.DirectoryInfo](Join-Path -Path $context.ConfigDir -ChildPath @("gh"))
        
        # stack directory leafs
        $context.IncludeDir    = [IO.DirectoryInfo](Join-Path -Path $context.StackDir -ChildPath @("include"))
        $context.MainEnvFile   = [IO.FileInfo](Join-Path -Path $context.StackDir -ChildPath @(".env"))
        $context.MainStackFile = [IO.FileInfo](Join-Path -Path $context.StackDir -ChildPath @("compose.yaml"))
        # state directory leafs
        $context.SecretsDir    = [IO.DirectoryInfo](Join-Path -Path $context.StateDir -ChildPath @(".secrets"))
        # docker
        $context.DefaultPUID   = [int]568
        $context.DefaultPGID   = [int]568
        $context.SocketPGID    = [int](Get-DockerHostPGID)
        # tenant
        if (-not (Test-Path $context.ConfigFile)) {
            @{Tenant = ""} | ConvertFrom-Json -Depth 9 | Set-Content -Path $context.ConfigFile
        }
        $context.TenantName    = [string]((Get-Content -Path $context.ConfigFile | ConvertFrom-Json -Depth 9 -AsHashTable).Tenant)
        $context.TenantFile    = [IO.FileInfo](Join-Path -Path $context.CommonDir -ChildPath @("deployinfo", ($context.TenantName.ToLower() + ".json")))
        $context.Tenant        = @{}
        if (Test-Path -Path $context.TenantFile) {
            $context.Tenant = Get-Content -Path $context.TenantFile | ConvertFrom-Json -Depth 9 -AsHashTable
            
            # to be replaced by sops ==============================================================================
            foreach ($key in $context.Tenant.Keys) {
                if ($context.Tenant.$key.Keys -and $context.Tenant.$key.ContainsKey("Password")) {
                    $context.Tenant.$key.Password = ConvertTo-SecureString -String $context.Tenant.$key.Password -AsPlainText
                }
            }
        }
        Write-Host ($context | Out-String )
    }

    end {
        $Script:Context = $context
        Write-Output $Script:Context
    }
}