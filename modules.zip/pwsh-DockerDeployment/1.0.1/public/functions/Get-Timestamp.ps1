function Get-Timestamp {
    [CmdletBinding()]
    [OutputType([string])]

    param()

    begin {

    }

    process {
        Write-Output -InputObject ("[" + (Get-Date -Format "yyyy-MM-ddTHH:mm:ss.ffffK") + "]" + [char][ConsoleKey]::Tab) #ISO 8601
    }

    end {

    }
}
