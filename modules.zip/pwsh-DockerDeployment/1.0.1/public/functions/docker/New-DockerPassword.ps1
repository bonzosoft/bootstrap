function New-DockerPassword {
    
    [CmdletBinding()]
    [OutputType()]
    param (
        [Parameter()]
        [ValidateNotNullOrWhiteSpace()]
        [SecureString]$Password = $null,

        [ValidateRange(16,256)]
        [int]$Length = 32,

        [Parameter(Mandatory, ParameterSetName = "Base64")]
        [switch]$AsBase64,

        [Parameter(Mandatory, ParameterSetName = "Base64Url")]
        [switch]$AsBase64Url,

        [Parameter(Mandatory, ParameterSetName = "JwtSecret")]
        [switch]$AsJwtSecret,

        [Parameter(Mandatory, ParameterSetName = "Argon2")]
        [switch]$AsArgon2,

        [Parameter(Mandatory, ParameterSetName = "BCrypt")]
        [switch]$AsBCrypt
    )
    
    begin {
        [string]$validChars     = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+[]{}:,.?ñ"
        #[string]$base64Chars    = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
        #[string]$base64UrlChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
        #$randomString = [Convert]::ToBase64String([Security.Cryptography.RandomNumberGenerator]::GetBytes(24))
        #$bytes = [System.Text.Encoding]::UTF8.GetBytes($string)
        #$string = [System.Text.Encoding]::UTF8.GetString($bytes)
        #$base64 = [Convert]::ToBase64String($bytes)
        #$base64Url = [Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+','-').Replace('/','_')
        #$string=[Convert]::FromBase64String($base64)

        # para reutilizar el hash de un argon2 usar esto:
        #$([Text.Encoding]::UTF8.GetString(([convert]::frombase64String($saltbase64))))

        [string]$seed = ""
        [string]$output = ""
        [string[]]$params = @()
    }

    process {
        if ($null -eq $Password) {
            $seed = ""
            foreach ($i in 1..$Length) {
                $seed += $validChars[(Get-Random -Minimum 0 -Maximum $validChars.Length)]
            }   
        }
        else {
            $seed = $Password | ConvertFrom-SecureString -AsPlainText
        }

        switch ($PSCmdlet.ParameterSetName) {
            {$PSItem -in @("Base64", "Base64Url", "JwtSecret")} {
                $output = [Convert]::ToBase64String( [System.Text.Encoding]::UTF8.GetBytes($seed))
                if ($PSItem -eq "Base64Url") {
                    $output = $output.TrimEnd('=').Replace('+','-').Replace('/','_')
                }
            }   
            "Argon2" {
                if (-not (Get-Command -Name "argon2" -ErrorAction SilentlyContinue)) {
                    throw "Command 'argon2' not found. Please install 'argon2' package."
                }

                $params = @(
                    ([Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(16)))
                    "-id"
                    "-t", 3
                    "-m", 18
                    "-p", 1
                    "-l", $Length
                    "-v", 13
                    "-e"
                )

                $output = $seed | argon2 @params 2> Variable:errStream
                if ($LASTEXITCODE -ne 0) {
                    throw ($errStream -join [Environment]::NewLine)
                }
            }
            "BCrypt" {
                if (-not (Get-Command -Name "mkpasswd" -ErrorAction SilentlyContinue)) {
                    throw "Command 'mkpasswd' not found. Please install 'whois' package."
                }

                $params = @(
                    "--method=bcrypt"
                    "--rounds=10"
                    "--stdin"
                )

                $output = $seed | mkpasswd @params 2> Variable:errStream
                if ($LASTEXITCODE -ne 0) {
                    throw ($errStream -join [Environment]::NewLine)
                }
            }
            default {
                throw "Unknown encryption method."
            }
        }

        Write-Output -InputObject $output
    }

    end {

    }

    clean {

    }
}