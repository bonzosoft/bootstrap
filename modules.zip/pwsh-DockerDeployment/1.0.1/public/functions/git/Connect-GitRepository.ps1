function Connect-GitRepository {
    [CmdletBinding()]
    [OutputType("System.Void", "Repository")]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [PSTypeName("Repository")]
        [PSCustomObject[]]$Repository,

        [Parameter()]
        [switch]$PassThru
    )

    begin {
        Test-GitBinaries

        [string[]]$stdStream = @()
        [string[]]$errStream = @()
        [string[]]$params = @()
       #[Hashtable]$splat = @{}
    }

    process {
        foreach ($item in $Repository) {
            try {
                if ($null -eq $item.Token) {
                    Write-Debug -Message "No token found for the repository. Skipping login."
                }
                else {                    
                    $params = @(
                        "-c", "credential.helper=cache"
                        "-c", "credential.interactive=false"
                        "credential"
                        "approve"
                    )
                    
                    $stdStream = @(
                        "protocol=" + $item.Domain.Scheme
                        "host="     + $item.Domain.Host
                        "username=" + "x-access-token"
                        "password=" + ($item.Token | ConvertFrom-SecureString -AsPlainText -ErrorAction 'SilentlyContinue')
                    ) | git @params 2> Variable:errStream
                    if ($LASTEXITCODE -ne 0) {
                        throw ($errStream -join [Environment]::NewLine)
                    }
                }

                if ($PassThru.IsPresent) {
                    Write-Output -InputObject $item
                }
                
                continue
            }
            catch {
                Disconnect-GitRepository -Repository $item -ErrorAction 'SilentlyContinue'

                if ($PassThru.IsPresent) {
                    Write-Error -Message $PSItem.Exception.Message -TargetObject $item
                }
                else {
                    Write-Error -Message $PSItem.Exception.Message
                }

                continue
            }
            finally {
                # nop
            }
        }
    }

    end {
        # nop
    }

    clean {
        # nop
    }
}