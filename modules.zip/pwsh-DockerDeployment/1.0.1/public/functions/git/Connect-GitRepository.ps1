function Connect-GitRepository {
    [CmdletBinding()]
    [OutputType("System.Void", "Repository")]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [PSTypeName("Repository")]
        [PSCustomObject[]]$Repository,

        [Parameter()]
        [switch]$PassThru
    )

    begin {
        [string[]]$stdInput = @()
        [string[]]$stdOutput = @()
        [string[]]$errOutput = @()
        [string[]]$params = @()
       #[hashtable]$splat = @{}
    }

    process {
        foreach ($item in $Repository) {
            $errOutput = @()

            try {
                if ($null -ne $item.Token) {
                    $stdInput = @(
                        "protocol=" + $item.Domain.Scheme
                        "host="     + $item.Domain.Host
                        "username=" + "x-access-token"
                        "password=" + ($item.Token | ConvertFrom-SecureString -AsPlainText -ErrorAction 'SilentlyContinue')
                    )
                    
                    $params = @(
                        "-c", "credential.helper=cache"    
                        "-c", "credential.interactive=false"
                        "credential"
                        "approve"
                    )
                    
                    $stdOutput = $stdInput | git @params 2> Variable:errOutput
                    if ($LASTEXITCODE -ne 0) {
                        throw ($errOutput -join [Environment]::NewLine)
                    }
                }
                else {
                    Write-Debug -Message "No token found for the repository. Skipping."
                }

                if ($PassThru.IsPresent) {
                    Write-Output -InputObject $item
                }
                
                continue
            }
            catch {
                Disconnect-GitRepository -Repository $item -ErrorAction 'SilentlyContinue'

                if ($PassThru.IsPresent) {
                    Write-Error -Message $PSItem.Exception.Message -TargetObject $item
                }
                else {
                    Write-Error -Message $PSItem.Exception.Message
                }

                continue
            }
            finally {
                # nop
            }
        }
    }

    end {
        # nop
    }

    clean {
        # nop
    }
}