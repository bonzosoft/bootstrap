function Get-GitRepository {
    [CmdletBinding()]
    [OutputType("System.Void", "Repository")]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [PSTypeName("Repository")]
        [PSCustomObject[]]$Repository,

        [Parameter()]
        [switch]$AsZip,

        [Parameter()]
        [switch]$PassThru
    )

    begin {
        Test-GitBinaries
        
        [string[]]$stdStream = @()
        [string[]]$errStream = @()
        [string[]]$params = @()
        [Hashtable]$splat = @{}
    }

    process {
        foreach ($item in $Repository) {
            try {
                Connect-GitRepository -Repository $item
            
                if (-not (Test-GitRepository -Repository $item)) {
                    $errStream = "Unable to reach remote source."
                    throw ($errStream -join [Environment]::NewLine)
                }

                if ($AsZip.IsPresent) { # as zip
                    $splat = @{
                        "Uri"     = $item.UriZip.AbsoluteUri
                        "OutFile" = $item.PathZip.FullName
                    }

                    if ($null -ne $item.Token) {
                        $splat += @{
                            "Authentication" = "Bearer"
                            "Token"          = $item.Token
                        }
                    }

                    Invoke-WebRequest @splat
                }
                else {
                    if (Test-GitRepository -Repository $item -Local) { # git fecth
                        $params = @(
                            "-C", $item.Directory.FullName
                            "-c", "credential.helper=cache"
                            "-c", "credential.interactive=false"
                            "fetch"
                            "origin"
                        )
    
                        $stdStream = git @params 2> Variable:errStream
                        if ($LASTEXITCODE -ne 0) {
                            throw ($errStream -join [Environment]::NewLine)
                        }
    
                        $params = @(
                            "-C", $item.Directory.FullName
                            "checkout"
                            $item.Branch
                        )
    
                        $stdStream = git @params 2> Variable:errStream
                        if ($LASTEXITCODE -ne 0) {
                            throw ($errStream -join [Environment]::NewLine)
                        }
    
                        $params = @(
                            "-C", $item.Directory.FullName
                            "reset"
                            "--hard"
                            "origin/" + $item.Branch
                        )
    
                        $stdStream = git @params 2> Variable:errStream
                        if ($LASTEXITCODE -ne 0) {
                            throw ($errStream -join [Environment]::NewLine)
                        }
                    }
                    else { # git clone
                        New-Item -Path $item.Directory.FullName -ItemType 'Directory' -Force | Out-Null
                        
                        $params = @(
                            "-C", $item.Directory.FullName
                            "-c", "credential.helper=cache"
                            "-c", "credential.interactive=false"
                            "clone"
                            "--branch", $item.Branch
                            "--single-branch"
                            "--recurse-submodules"
                            $item.Uri.AbsoluteUri
                        )
    
                        $stdStream = git @params 2> Variable:errStream
                        if ($LASTEXITCODE -ne 0) {
                            throw ($errStream -join [Environment]::NewLine)
                        }
                    }
                }
                
                if ($PassThru.IsPresent) {
                    Write-Output -InputObject $item
                }
                
                continue
            }
            catch {
                if ($PassThru.IsPresent) {
                    Write-Error -Message $PSItem.Exception.Message -TargetObject $item
                }
                else {
                    Write-Error -Message $PSItem.Exception.Message
                }

                continue
            }
            finally {
                Disconnect-GitRepository -Repository $item -ErrorAction 'SilentlyContinue'
            }
        }
    }

    end {
        # nop
    }

    clean {
        # nop
    }
}