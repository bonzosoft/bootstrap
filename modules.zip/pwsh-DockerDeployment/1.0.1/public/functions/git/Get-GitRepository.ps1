function Get-GitRepository {
    [CmdletBinding()]
    [OutputType("System.Void", "Repository")]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [PSTypeName("Repository")]
        [PSCustomObject[]]$Repository,

        [Parameter()]
        [switch]$AsZip,

        [Parameter()]
        [switch]$PassThru
    )

    begin {
       #[string[]]$stdInput = @()
        [string[]]$stdOutput = @()
        [string[]]$errOutput = @()
        [string[]]$params = @()
        [hashtable]$splat = @{}
    }

    process {
        foreach ($item in $Repository) {
            $errOutput = @()

            try {
                Connect-GitRepository -Repository $item
            
                if (-not (Test-GitRepository -Repository $item)) {
                    $errOutput = "Unable to reach remote source."
                    throw ($errOutput -join [Environment]::NewLine)
                }

                if ($AsZip.IsPresent) {
                    # as zip
                    $splat = @{
                        "Uri"     = $item.UriZip.AbsoluteUri
                        "OutFile" = $item.PathZip.FullName
                    }

                    if ($null -ne $item.Token) {
                        $splat += @{
                            "Authentication" = "Bearer"
                            "Token"          = $item.Token
                        }
                    }

                    Invoke-WebRequest @splat
                }
                else {
                    if (Test-GitRepository -Repository $item -Local) {
                        # git fecth

                        $params = @(
                            "-C", $item.Directory.FullName
                            "-c", "credential.helper=cache"
                            "-c", "credential.interactive=false"
                            "fetch"
                            "origin"
                        )
    
                        $stdOutput = git @params 2> Variable:errOutput
                        if ($LASTEXITCODE -ne 0) {
                            throw ($errOutput -join [Environment]::NewLine)
                        }
    
                        $params = @(
                            "-C", $item.Directory.FullName
                            "checkout"
                            $item.Branch
                        )
    
                        $stdOutput = git @params 2> Variable:errOutput
                        if ($LASTEXITCODE -ne 0) {
                            throw ($errOutput -join [Environment]::NewLine)
                        }
    
                        $params = @(
                            "-C", $item.Directory.FullName
                            "reset"
                            "--hard"
                            "origin/" + $item.Branch
                        )
    
                        $stdOutput = git @params 2> Variable:errOutput
                        if ($LASTEXITCODE -ne 0) {
                            throw ($errOutput -join [Environment]::NewLine)
                        }
                    }
                    else {
                        # git clone

                        New-Item -Path $item.Directory.FullName -ItemType 'Directory' -Force | Out-Null              
                        
                        $params = @(
                            "-C", $item.Directory.FullName
                            "-c", "credential.helper=cache"
                            "-c", "credential.interactive=false"
                            "clone"
                            "--branch", $item.Branch
                            "--single-branch"
                            "--recurse-submodules"
                            $item.Uri.AbsoluteUri
                        )
    
                        $stdOutput = git @params 2> Variable:errOutput
                        if ($LASTEXITCODE -ne 0) {
                            throw ($errOutput -join [Environment]::NewLine)
                        }
                    }
                }
                
                if ($PassThru.IsPresent) {
                    Write-Output -InputObject $item
                }
                
                continue
            }
            catch {
                if ($PassThru.IsPresent) {
                    Write-Error -Message $PSItem.Exception.Message -TargetObject $item
                }
                else {
                    Write-Error -Message $PSItem.Exception.Message
                }

                continue
            }
            finally {
                Disconnect-GitRepository -Repository $item -ErrorAction 'SilentlyContinue'
            }
        }
    }

    end {
        # nop
    }

    clean {
        # nop
    }
}