function New-GitRepository {
    [CmdletBinding()]
    [OutputType("Repository")]

    param (
        [Parameter()]
        [ValidateNotNull()]
        [Uri]$Domain = "https://github.com",

        [Parameter()]
        [ValidateNotNullOrWhiteSpace()]
        [string]$Organization = "bonzosoft",

        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNullOrWhiteSpace()]
        [string[]]$Name,

        [Parameter()]
        [ValidateNotNullOrWhiteSpace()]
        [string]$Branch = "main",

        [Parameter()]
        [ValidateNotNull()]
        [SecureString]$Token = $null,

        [Parameter()]
        [ValidateNotNull()]
        [IO.DirectoryInfo]$Directory = $PWD.Path
    )
    
    begin {
        [PSCustomObject]$repository = $null
    }

    process {
        foreach ($item in $Name) {
            try {
                $repository = [PSCustomObject]@{
                    PSTypeName     = "Repository"
                    "Domain"       = [Uri]$Domain
                    "Organization" = [string]$Organization
                    "Name"         = [string]$item
                    "Branch"       = [string]$Branch
                    "Token"        = [SecureString]$Token
                    "Directory"    = [IO.DirectoryInfo]$Directory
                }
    
                $repository | Add-Member -MemberType 'ScriptProperty' -Name "Path" {
                    return [IO.FileInfo]::New((Join-Path -Path $this.Directory -ChildPath @($this.Name + ".git")))
                }
    
                $repository | Add-Member -MemberType 'ScriptProperty' -Name "PathZip" {
                    return [IO.FileInfo]::New((Join-Path -Path $this.Directory -ChildPath @($this.Name + ".zip")))
                }
    
                $repository | Add-Member -MemberType 'ScriptProperty' -Name "Uri" {
                    return [Uri]::New($this.Domain, @($this.Organization, ($this.Name + ".git")) -join("/"))
                }
    
                $repository | Add-Member -MemberType 'ScriptProperty' -Name "UriZip" {
                    return [Uri]::New($this.Domain, @($this.Organization, $this.Name, "archive", "refs", "heads", ($this.Name + ".zip")) -join("/"))
                }
    
                Write-Output -InputObject $repository
    
                continue
            }
            catch {
                Write-Error -Message $PSItem.Exception.Message

                continue
            }
            finally {
                # nop
            }
        }
    }

    end {
        # nop
    }

    clean {
        # nop
    }
}