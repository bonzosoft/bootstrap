function Test-VaultBinaries {
    [CmdletBinding()]
    [OutputType([bool])]

    param (
        # nop
    )

    if (-not (Get-Command -Name "git" -ErrorAction 'SilentlyContinue')) {
        throw "Command 'git' not found. Please install 'git' package."
    }

    return $true
}