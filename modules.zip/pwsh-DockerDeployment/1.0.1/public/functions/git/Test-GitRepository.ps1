function Test-GitRepository {
    [CmdletBinding()]
    [OutputType([bool])]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [PSTypeName("Repository")]
        [PSCustomObject[]]$Repository,

        [Parameter()]
        [switch]$Local
    )

    begin {
       #[string[]]$stdInput = @()
        [string[]]$stdOutput = @()
        [string[]]$errOutput = @()
        [string[]]$params = @()
       #[hashtable]$splat = @{}
    }

    process {
        foreach ($item in $Repository) {
            $errOutput = @()

            try {
                if ($Local.IsPresent) {
                    $params = @(
                        "-C", $item.Directory.FullName
                        "rev-parse"
                        "--is-inside-work-tree"
                    )

                    $stdOutput = git @params 2> Variable:errOutput
                    if ($LASTEXITCODE -ne 0) {
                        throw ($errOutput -join [Environment]::NewLine)
                    }
                }
                else {
                    Connect-GitRepository -Repository $item

                    $params = @(
                        "-c", "credential.helper=cache"    
                        "-c", "credential.interactive=false"
                        "ls-remote"
                        "--heads"
                        $item.Uri.AbsoluteUri
                        $item.Branch
                    )

                    $stdOutput = git @params 2> Variable:errOutput
                    if ($LASTEXITCODE -ne 0) {
                        throw ($errOutput -join [Environment]::NewLine)
                    }

                    if ([string]::IsNullOrWhiteSpace($stdOutput)) {
                        throw "Branch not found in the repository."
                    }
                }
                
                Write-Output -InputObject $true
                
                continue
            }
            catch {
                Write-Debug -Message $PSItem.Exception.Message

                Write-Output -InputObject $false

                continue
            }
            finally {
                if (-not $Local.IsPresent) {
                    Disconnect-GitRepository -Repository $item -ErrorAction 'SilentlyContinue'
                }
            }
        }
    }

    end {
        # nop
    }

    clean {
        # nop
    }
}