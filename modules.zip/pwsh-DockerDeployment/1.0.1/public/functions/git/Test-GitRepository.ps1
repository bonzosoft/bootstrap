function Test-GitRepository {
    [CmdletBinding()]
    [OutputType([bool])]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [PSTypeName("Repository")]
        [PSCustomObject[]]$Repository,

        [Parameter()]
        [switch]$Local
    )

    begin {
        Test-GitBinaries
        
        [string[]]$stdStream = @()
        [string[]]$errStream = @()
        [string[]]$params = @()
       #[Hashtable]$splat = @{}
    }

    process {
        foreach ($item in $Repository) {
            try {
                if ($Local.IsPresent) {
                    $params = @(
                        "-C", $item.Directory.FullName
                        "rev-parse"
                        "--is-inside-work-tree"
                    )

                    $stdStream = git @params 2> Variable:errStream
                    if ($LASTEXITCODE -ne 0) {
                        throw ($errStream -join [Environment]::NewLine)
                    }
                }
                else {
                    $params = @(
                        "-c", "credential.helper=cache"
                        "-c", "credential.interactive=false"
                        "ls-remote"
                        "--heads"
                        $item.Uri.AbsoluteUri
                        $item.Branch
                    )

                    $stdStream = git @params 2> Variable:errStream
                    if ($LASTEXITCODE -ne 0) {
                        throw ($errStream -join [Environment]::NewLine)
                    }

                    if ([string]::IsNullOrWhiteSpace($stdStream)) {
                        throw "Branch not found in the repository."
                    }
                }
                
                Write-Output -InputObject $true
                
                continue
            }
            catch {
                Write-Debug -Message $PSItem.Exception.Message

                Write-Output -InputObject $false

                continue
            }
            finally {
                #nop 
            }
        }
    }

    end {
        # nop
    }

    clean {
        # nop
    }
}