function ConvertTo-HashArgon2 {
    [CmdletBinding(DefaultParameterSetName = "SaltLength")]
    [OutputType("System.String", "HashArgon2")]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [SecureString[]]$Password,

        [Parameter(Mandatory, ParameterSetName = "SaltString")]
        [ValidateNotNullOrWhiteSpace()]
        [string]$Salt,

        [Parameter(ParameterSetName = "SaltLength")]
        [ValidateRange(8,128)]
        [int]$SaltLength = 16,

        [Parameter()]
        [ValidateSet("id", "i", "d")]
        [string]$Algorithm = "id",

        [Parameter()]
        [ValidateRange(16, 512)]
        [int]$Length = 32,

        [ValidateRange(1, 10)]
        [int]$Iterations = 3,

        [ValidateRange(12, 24)]
        [int]$Memory = 18, # 2^18 KiB = 256 MiB

        [ValidateRange(1, 32)]
        [int]$Parallelism = 1,

        [Parameter()]
        [ValidateSet(10, 13)]
        [int]$Version = 13,

        [Parameter()]
        [switch]$AsObject
    )

    begin {
        if (-not (Get-Command -Name "argon2" -ErrorAction 'SilentlyContinue')) {
            throw "Command 'argon2' not found. Please install 'argon2' package."
        }
       
       #[string[]]$stdStream = @()
       #[string[]]$errStream = @()
       #[string[]]$params = @()
       #[Hashtable]$splat = @{}
        [object]$output = $null
    }

    process {
        foreach ($item in $Password) {
            try {
                switch ($PScmdlet.ParameterSetName) {
                    "SaltLength" {
                        $saltString = [Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes($SaltLength))
                    }
                    "SaltString" {
                        $saltString = $Salt
                    }
                    default {
                        throw "Unknown parameter set name."
                    }
                }

                $output = [PSCustomObject]@{
                    PSTypeName    = "HashArgon2"
                    "Password"    = [SecureString]$item
                    "Algorithm"   = [string]$Algorithm
                    "Iterations"  = [int]$Iterations
                    "Memory"      = [int]$Memory
                    "Parallelism" = [int]$Parallelism
                    "Length"      = [int]$Length
                    "Version"     = [int]$Version
                    "Salt"        = [string]$saltString
                    "Hash"        = [string]$null
                    "FullHash"    = [string]$null
                }
                $output | Add-Member -MemberType 'ScriptMethod' -Name "Refresh" -Value {
                    [string[]]$errStream = @()
                    [string[]]$params = @()

                    $params = @(
                        $this.Salt
                        "-" + $this.Algorithm
                        "-t", $this.Iterations
                        "-m", $this.Memory
                        "-p", $this.Parallelism
                        "-l", $this.Length
                        "-v", $this.Version
                        "-e"
                    )
                    
                    $this.FullHash = ($this.Password | ConvertFrom-SecureString -AsPlainText) | argon2 @params 2> Variable:errStream
                    if ($LASTEXITCODE -ne 0) {
                        throw ($errStream -join [Environment]::NewLine)
                    }

                    $this.Hash = ($this.FullHash -split '\$')[-1]
                    
                    return
                }

                $output.Refresh()

                if ($AsObject.IsPresent) {
                    Write-Output -InputObject $output
                }
                else {
                    Write-Output -InputObject $output.FullHash
                }

                continue
            }
            catch {
                Write-Error -Message $PSItem.Exception.Message

                continue
            }
            finally {

            }
        }
    }

    end {
        # nop
    }

    clean {
        # nop
    }
}