function ConvertTo-HashBCrypt {
    [CmdletBinding()]
    [OutputType([string])]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [SecureString[]]$Password,

        [Parameter()]
        [ValidateRange(8, 16)]
        [int]$Cost = 12 # 2^12 = 4096 iterations
    )

    begin {
        if (-not (Get-Command -Name "mkpasswd" -ErrorAction 'SilentlyContinue')) {
            throw "Command 'mkpasswd' not found. Please install 'whois' package."
        }
       #[string[]]$stdStream = @()
        [string[]]$errStream = @()
        [string[]]$params = @()
       #[Hashtable]$splat = @{}
        [object]$output = $null
    }

    process {
        foreach ($item in $Password) {
            try {
                $params = @(
                    "--method=bcrypt"
                    #"--salt=" + $Salt
                    "--rounds=" + $Cost
                    "--stdin"
                )
                $output = ($item | ConvertFrom-SecureString -AsPlainText) | mkpasswd @params 2> Variable:errStream
                if ($LASTEXITCODE -ne 0) {
                    throw ($errStream -join [Environment]::NewLine)
                }
                
                Write-Output -InputObject $output

                continue
            }
            catch {
                Write-Error -Message $PSItem.Exception.Message
    
                continue
            }
            finally {
                # nop
            }
        }
    }

    end {
        # nop
    }

    clean {
        # nop
    }
}