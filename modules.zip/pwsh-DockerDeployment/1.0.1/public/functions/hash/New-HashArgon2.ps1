<#
    .EXAMPLE
    $var = "sometext" | ConvertTo-SecureString -AsPlainText | New-HashArgon2
    $var.Refresh()
    $var.Hash | ConvertFrom-SecureString -AsPlainText
    $var.HashBase64
    $var.HashBytes
    "contraseña" | ConvertTo-SecureString -AsPlainText | ConvertFrom-SecureString -Key ($var.HashBytes)

    #
    # Format:
    # $argon2id$v=19$m=262144,t=3,p=1$BASE64_SALT$BASE64_HASH
    #
#>
function New-HashArgon2 {
    [CmdletBinding()]
    [OutputType([PSCustomObject])]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [SecureString]$Password,

        [Parameter()]
        [ValidateNotNullOrWhiteSpace()]
        [string]$Salt = [Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(16)),

        [Parameter()]
        [ValidateSet("id", "i", "d")]
        [string]$Algorithm = "id",

        [Parameter()]
        [ValidateSet(16, 24, 32)]
        [int]$Length = 32,

        [ValidateRange(1,10)]
        [int]$Iterations = 3,

        [ValidateRange(12,24)]
        [int]$Memory = 18, # 2^18 KiB = 256 MiB

        [ValidateRange(1,32)]
        [int]$Parallelism = 1,

        [Parameter()]
        [ValidateSet(10, 13)]
        [int]$Version = 13,

        [Parameter()]
        [switch]$PassThru
    )

    begin {
        [PSCustomObject]$hash = $null
    }

    process {
        $hash = [PSCustomObject]@{
            "Password"    = [SecureString]$Password
            "Algorithm"   = [string]$Algorithm
            "Iterations"  = [int]$Iterations
            "Memory"      = [int]$Memory
            "Parallelism" = [int]$Parallelism
            "Length"      = [int]$Length
            "Version"     = [int]$Version
            "Salt"        = [string]$Salt
            "FullHash"    = $null
        }
        $hash | Add-Member -MemberType 'ScriptMethod' -Name "Refresh" -Value {
            $params = @(
                $this.Salt
                "-" + $this.Algorithm
                "-t", $this.Iterations
                "-m", $this.Memory
                "-p", $this.Parallelism
                "-l", $this.Length
                "-v", $this.Version
                "-e"
            )
            $stdStream = $this.Password | ConvertFrom-SecureString -AsPlainText | argon2 @params 2> Variable:errStream
            if ($LASTEXITCODE -ne 0) {
                throw ($errStream -join [Environment]::NewLine)
            }
            $this.FullHash = $stdStream #| ConvertTo-SecureString -AsPlainText
        }
        $hash | Add-Member -MemberType 'ScriptProperty' -Name "HashBase64" -Value {
            $hash = $this.FullHash | ConvertFrom-String -AsPlainText
            $hash = $hash.Split("$")[-1]
            $hash = $hash + ("=" * ((4-($hash.Length % 4)) % 4))
            return $hash | ConvertTo-SecureString -AsPlainText
        }
        $hash | Add-Member -MemberType 'ScriptProperty' -Name "HashBytes" -Value {
            return [Convert]::FromBase64String($this.HashBase64)
        }

        $hash.Refresh()

        if ($PassThru.IsPresent) {
            Write-Output -InputObject $hash
        }
        else {
            Write-Output -InputObject $hash.FullHash
        }
        
    }

    end {

    }

    clean {

    }
}
