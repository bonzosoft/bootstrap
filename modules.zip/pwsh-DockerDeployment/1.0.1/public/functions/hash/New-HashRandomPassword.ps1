function New-HashRandomPassword {
    [CmdletBinding(DefaultParameterSetName = "ASCII")]
    [OutputType([SecureString])]

    param (
        [Parameter(ValueFromPipeline)]
        [ValidateRange(16, 512)]
        [int[]]$Length = 32,

        [Parameter(Mandatory, ParameterSetName = "Base64")]
        [switch]$AsBase64,

        [Parameter(Mandatory, ParameterSetName = "Base64Url")]
        [switch]$AsBase64Url
    )

    begin {
        [string]$asciiChars     = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+[]{}:,.?"
       #[string]$base64Chars    = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
       #[string]$base64UrlChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"

       #[string[]]$stdStream = @()
       #[string[]]$errStream = @()
       #[string[]]$params = @()
       #[Hashtable]$splat = @{}
        
        [string]$output = ""
    }

    process {
        foreach ($item in $Length) {
            try {
                switch ($PSCmdlet.ParameterSetName) {
                    "ASCII" {
                        $output = ""
                        foreach ($i in 1..$item) {
                            $output += $asciiChars[(Get-Random -Minimum 0 -Maximum $asciiChars.Length)]
                        }
                    }
                    "Base64" {
                        $output = [Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes($item))
                    }
                    "Base64Url" {
                        $output = [Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes($item)).TrimEnd('=').Replace('+','-').Replace('/','_')
                    }
                    default {
                        throw "Unknown parameter set name '$($PSCmdlet.ParameterSetName)'."
                    }
                }
    
                Write-Output -InputObject $output

                continue
            }
            catch {
                Write-Error -Message $PSItem.Exception.Message
            }
            finally{
                # nop
            }
        }
    }

    end {
        # nop
    }

    clean {
        # nop
    }
}