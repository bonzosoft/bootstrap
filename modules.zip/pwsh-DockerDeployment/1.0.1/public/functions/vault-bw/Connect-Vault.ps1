function Connect-Vault {
    [CmdletBinding()]
    [OutputType([void])]



    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [pscredential]$Credential
    )

    begin {
        [string[]]$stdStream = @()
        [string[]]$errStream = @()
    }

    process {
        $stdStream = (ConvertFrom-SecureString -SecureString $Credential.Password -AsPlainText) | 
        bw login $Credential.UserName 2> Variable:errStream
        if ($LASTEXITCODE -ne 0) {
            throw ($errStream -join [Environment]::NewLine)
        }
    }

    end {
        
    }
}