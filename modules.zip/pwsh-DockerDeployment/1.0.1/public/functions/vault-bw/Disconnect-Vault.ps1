function Disconnect-Vault {
    [CmdletBinding()]
    [OutputType([void])]

    param (

    )

    begin {
        [string[]]$stdStream = @()
        [string[]]$errStream = @()
    }

    process {
        $stdStream = bw logout 2> Variable:errStream
        if ($LASTEXITCODE -ne 0) {
            throw ($errStream -join [Environment]::NewLine)
        }
    }

    end {

    }
}