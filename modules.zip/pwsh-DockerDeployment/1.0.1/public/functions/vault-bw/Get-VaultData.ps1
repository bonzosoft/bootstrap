function Get-VaultData {
    [CmdletBinding()]
    [OutputType([object])]

    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [securestring]$Session,

        [Parameter(Mandatory)]
        [ValidateSet("item", "username", "password", "uri", "totp", "notes", `
        "exposed", "attachment", "folder", "collection", "org-collection", `
        "organization", "template", "fingerprint", "send", "tenant", `
        IgnoreCase = $true)]
        [string]$ItemType,

        [Parameter(Mandatory)]
        [ValidateNotNullOrWhiteSpace()]
        [string]$Name
    )

    begin {
        #[string[]]$stdStream = @()
        [string[]]$errStream = @()

        [object]$data = $null
    }

    process {
        switch ($ItemType) {
            "tenant" {
                [hashtable]$data = bw get notes $Name --session (ConvertFrom-Securestring -SecureString $Session -AsPlainText) 2> variable:errStream |
                ConvertFrom-Json -Depth 9 -AsHashtable
            }
            default {
                [string]$data = bw get $ItemType $Name --session (ConvertFrom-Securestring -SecureString $Session -AsPlainText) 2> variable:errStream
            }
        }
        if ($LASTEXITCODE -ne 0) {
            throw ($errStream -join [Environment]::NewLine)
        }
    }

    end {
        Write-Output -InputObject $data
    }
}