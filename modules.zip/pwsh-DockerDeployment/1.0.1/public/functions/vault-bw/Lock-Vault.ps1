function Lock-Vault {
    [CmdletBinding()]
    [OutputType([void])]

    param(
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [securestring]$Session
    )

    begin {
        [string[]]$stdStream = @()
        [string[]]$errStream = @()
    }

    process { 
        $stdStream = bw lock --session $Session 2> Variable:errStream
        if ($LASTEXITCODE -ne 0) {
            throw ($errStream -join [Environment]::NewLine)
        }
    }

    end {
        
    }
}