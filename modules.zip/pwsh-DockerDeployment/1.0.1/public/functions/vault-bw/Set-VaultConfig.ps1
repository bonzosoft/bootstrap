function Set-VaultConfig {
    [CmdletBinding()]
    [OutputType([void])]

    param (
        [Parameter()]
        [ValidateNotNullOrWhiteSpace()]
        [IO.DirectoryInfo]$Path,
    
        [Parameter()]
        [ValidateNotNullOrWhiteSpace()]
        [string]$Uri
    )

    begin {
        [string[]]$stdStream = @()
        [string[]]$errStream = @()
    }

    process {
        if ((Test-Vault) -eq [VaultStatus]::Locked) {
            throw "Vault server cannot be changed while the vault is locked."
        }

        if ($Uri) {
            $stdStream = bw config server $Uri 2> Variable:errStream
            if ($LASTEXITCODE -ne 0) {
                throw ($errStream -join [Environment]::NewLine)
            }
        }

        if ($Path) {
            $Env:BW_APPDATA_DIR = $Path.FullName
        }
    }

    end {

    }
}