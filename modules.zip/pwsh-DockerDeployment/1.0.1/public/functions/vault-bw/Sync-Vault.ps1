function Sync-Vault {
    [CmdletBinding()]
    [OutputType([void])]

    param(
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [SecureString]$Session
    )

    begin {
        [string[]]$stdStream = @()
        [string[]]$errStream = @()
    }

    process { 
        $stdStream = bw sync --session $Session 2> Variable:errStream
        if ($LASTEXITCODE -ne 0) {
            throw ($errStream -join [Environment]::NewLine)
        }
    }

    end {
        
    }
}