function Test-Vault {
    [CmdletBinding()]
    [OutputType([vaultstatus])]

    param (
        [Parameter()]
        [ValidateNotNull()]
        [securestring]$Session = $null
    )

    begin {
        #[string[]]$stdStream = @()
        [string[]]$errStream = @()

        [string]$status = ""
        [vaultstatus]$result = [vaultstatus]::Unknown
    }

    process {
        if ($null -eq $Session) {
            $status = (bw status 2> variable:errStream |
            ConvertFrom-Json -AsHashTable).status
        }
        else {
            $status = (bw status --session (ConvertFrom-Securestring -SecureString $Session -AsPlainText) 2> variable:errStream |
            ConvertFrom-Json -AsHashTable).status
        }
        if ($LASTEXITCODE -ne 0) {
            throw ($errStream -join [Environment]::NewLine)
        }

        switch ($status) {
            "unlocked" {
                $result = [VaultStatus]::Unlocked
            }
            "locked" {
                $result = [VaultStatus]::Locked
            }
            "unauthenticated" {
                $result = [VaultStatus]::Unauthenticated
            }
            default {
                throw "Unknown vault status."
            }
        }
    }

    end {
        Write-Output -InputObject $result
    }
}