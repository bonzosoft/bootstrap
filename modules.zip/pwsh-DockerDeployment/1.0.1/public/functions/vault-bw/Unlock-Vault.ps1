function Unlock-Vault {
    [CmdletBinding()]
    [OutputType([securestring])]
    
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [pscredential]$Credential
    )

    begin {
        #[string[]]$stdStream = @()
        [string[]]$errStream = @()

        [securestring]$session = $null
    }

    process {
        #
        # este script usa $session para devolver la se BW_SESSION pero se podría hacer
        # declarando la variable $Env:BW_SESSION = bw unlock $passwordPointer --raw
        #

        $session = ((ConvertFrom-SecureString -SecureString $Credential.Password -AsPlainText) | 
        bw unlock --raw 2> Variable:errStream) | ConvertTo-SecureString -AsPlainText
        if ($LASTEXITCODE -ne 0) {
            throw ($errStream -join [Environment]::NewLine)
        }
    }

    end {
        Write-Output -InputObject $session
    }
}