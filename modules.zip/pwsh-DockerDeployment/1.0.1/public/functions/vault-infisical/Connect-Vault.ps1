function Connect-Vault {
    [CmdletBinding()]
    [OutputType("System.Void", "VaultInfisical")]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [PSTypeName("VaultInfisical")]
        [PSCustomObject[]]$Vault,

        [Parameter()]
        [switch]$PassThru
    )

    begin {
        [string[]]$stdInput = @()
       #[string[]]$stdOutput = @()
        [string[]]$errOutput = @()
        [string[]]$params = @()
    }

    process {
        foreach ($item in $Vault) {
            $params = @(
                "login"
                "--domain",           $item.Domain.ToString()
                "--email",            $item.Credential.UserName
                "--password",         "-"
                "--organization-id",  $item.Organization.ToString()
                "--telemetry=false"
                "--plain"
                "--silent"
            )

            $item.Token = ($item.Credential.Password | ConvertFrom-SecureString -AsPlainText) | infisical @params 2> Variable:errOutput | ConvertTo-SecureString -AsPlainText
            if ($LASTEXITCODE -ne 0) {
                Write-Error -Message ($errOutput -join [Environment]::NewLine)
            }
    
            if ($PassThru.IsPresent) {
                Write-Output -InputObject $item
            }
        }
    }
    end {

    }

    clean {
        
    }
}