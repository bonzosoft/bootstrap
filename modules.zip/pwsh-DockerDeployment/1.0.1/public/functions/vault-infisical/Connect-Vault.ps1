function Connect-Vault {
    [CmdletBinding()]
    [OutputType("System.Void", "VaultInfisical")]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [PSTypeName("VaultInfisical")]
        [PSCustomObject[]]$Vault,

        [Parameter()]
        [switch]$PassThru
    )

    begin {
        Test-VaultBinaries

       #[string[]]$stdStream = @()
        [string[]]$errStream = @()
        [string[]]$params = @()
       #[Hashtable]$splat = @{}
       
       Set-Item -Path "Env:INFISICAL_DISABLE_UPDATE_CHECK" -Value "true" -Force
    }

    process {
        foreach ($item in $Vault) {
            try {
                if ($null -ne $item.Token) {
                    Write-Debug -Message "Vault already connected. Skipping login."
                }
                else {
                    Set-Item -Path "Env:INFISICAL_PASSWORD" -Value ($item.Credential.GetNetworkCredential().Password) -Force

                    $params = @(
                        "login"
                        "--domain",           $item.Domain.AbsoluteUri
                        "--email",            $item.Credential.GetNetworkCredential().UserName
                        #"--password",        $item.Credential.GetNetworkCredential().Password
                        "--organization-id",  $item.Organization.Guid
                        "--telemetry=false"
                        "--plain"
                        "--silent"
                    )
    
                    $item.Token = infisical @params 2> Variable:errStream | ConvertTo-SecureString -AsPlainText
                    if ($LASTEXITCODE -ne 0) {
                        throw ($errStream -join [Environment]::NewLine)
                    }
                }

                if ($PassThru.IsPresent) {
                    Write-Output -InputObject $item
                }

                continue
            }
            catch {
                if ($PassThru.IsPresent) {
                    Write-Error -Message $PSItem.Exception.Message -TargetObject $item
                }
                else {
                    Write-Error -Message $PSItem.Exception.Message
                }

                continue
            }
            finally {
                Set-Item -Path "Env:INFISICAL_PASSWORD" -Value "" -Force
            }
        }
    }
    end {
        # nop
    }

    clean {
        Remove-Item -Path "Env:INFISICAL_PASSWORD" -Force -ErrorAction 'SilentlyContinue'
    }
}