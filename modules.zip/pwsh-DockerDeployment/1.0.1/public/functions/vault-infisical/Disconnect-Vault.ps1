function Disconnect-Vault {
    [CmdletBinding()]
    [OutputType([void], [pscustomobject])]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [pscustomobject[]]$Vault,

        [Parameter()]
        [switch]$PassTrhu
    )

    begin {
        #[string[]]$stdStream = @()
        #[string[]]$errStream = @()
    }

    process {
        foreach ($item in $Vault) {
            $item.Token = [securestring]$null

            if ($PassThru.IsPresent()) {
                Write-Output -InputObject $item
            }
        }
    }
    
    end {
        
    }

    clean {
        Remove-Item -Path "Env:INFISICAL_TOKEN" -Force
    }
}