function Disconnect-Vault {
    [CmdletBinding()]
    [OutputType("System.Void", "VaultInfisical")]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [PSTypeName("VaultInfisical")]
        [PSCustomObject[]]$Vault,

        [Parameter()]
        [switch]$PassTrhu
    )

    begin {
        Test-VaultBinaries

        #[string[]]$stdStream = @()
        #[string[]]$errStream = @()
        #[string[]]$params = @()
        #[Hashtable]$splat = @{}
    }

    process {
        foreach ($item in $Vault) {
            try {
                $item.Token = $null

                if ($PassThru.IsPresent) {
                    Write-Output -InputObject $item
                }

                continue
            }
            catch {
                if ($PassThru.IsPresent) {
                    Write-Error -Message $PSItem.Exception.Message -TargetObject $item
                }
                else {
                    Write-Error -Message $PSItem.Exception.Message
                }

                continue
            }
            finally {
                # nop
            }
        }
    }
    
    end {
        # nop
    }

    clean {
        Remove-Item -Path "Env:INFISICAL_TOKEN" -Force -ErrorAction 'SilentlyContinue'
        Remove-Item -Path "Env:INFISICAL_PASSWORD" -Force -ErrorAction 'SilentlyContinue'
        Remove-Item -Path "Env:INFISICAL_DISABLE_UPDATE_CHECK" -Force -ErrorAction 'SilentlyContinue'
    }
}