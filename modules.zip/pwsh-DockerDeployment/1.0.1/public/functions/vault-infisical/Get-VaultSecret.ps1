function Get-VaultSecret {
    [CmdletBinding(DefaultParameterSetName = "Path")]
    [OutputType([string[]], [ordered])]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [pscustomobject[]]$Vault,

        [Parameter(Mandatory, ParameterSetName = "Secret")]
        [ValidateNotNullOrWhiteSpace()]
        [string[]]$Secret,

        [Parameter()]
        [ValidateNotNullOrWhiteSpace()]
        [string[]]$Path = "/",

        [Parameter()]
        [ValidateSet("default", "dev", "staging", "prod")]
        [string]$Environment = "default",

        [Parameter()]
        [switch]$AsHashtable
    )

    begin {
        #[string[]]$stdStream = @()
        [string[]]$errStream = @()
        [string[]]$params = @()
        [string]$EnvironmentItem = ""
        [string[]]$rawValue = @()
        [object]$outValue = $null
    }

    process {
        foreach ($vaultItem in $Vault) {
            if (-not (Test-Vault -Vault $vaultItem)) {
                Write-Error -Message "Vault not connected."
                continue
            }

            if ($Environment -eq "default") {
                $environmentItem = $vaultItem.Environment
            }
            else {
                $environmentItem = $Environment
            }

            Set-Item -Path "Env:INFISICAL_TOKEN" -Value ($vaultItem.Token | ConvertFrom-SecureString -AsPlainText)

            foreach ($pathItem in $Path) {
                $params = @(
                    "secrets"
                )
    
                if ($Secret) {
                    $params += @(
                        "get"
                        $Secret
                    )
                }
    
                $params += @(
                    "--domain", $vaultItem.Domain.ToString()
                    "--projectId", $vaultItem.Project.ToString()
                    "--env", $environmentItem
                    "--path", $pathItem
                    "--telemetry=false"
                )
    
                if ($AsHashtable.IsPresent) {
                    $params += "--output=json"
                }
                else {
                    $params += "--plain"
                }

                $rawValue = infisical @params 2> Variable:errStream
                if ($LASTEXITCODE -ne 0) {
                    Write-Error -Message ($errStream -join [Environment]::NewLine)
                    continue
                }
                if ($AsHashtable.IsPresent) {
                    $outValue = [ordered]@{}
                    foreach ($valueItem in ($rawValue | ConvertFrom-Json -AsHashtable)){
                        try {
                            $outValue.$($valueItem.secretKey) = $valueItem.secretValue | ConvertFrom-Json -Depth 9 -AsHashtable
                        }
                        catch {
                            $outValue.$($valueItem.secretKey) = $valueItem.secretValue
                        }
                    }
                }
                else {
                    $outValue = $rawValue
                }

                Write-Output -InputObject $outValue
            }

        }
    }

    end {
        
    }

    clean {
        Remove-Item -Path "Env:INFISICAL_TOKEN" -Force -ErrorAction 'SilentlyContinue'
    }
}
