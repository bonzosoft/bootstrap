function Get-VaultSecret {
    [CmdletBinding(DefaultParameterSetName = "Path")]
    [OutputType([string[]], [ordered])]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [PSTypeName("VaultInfisical")]
        [PSCustomObject[]]$Vault,

        [Parameter(Mandatory, ParameterSetName = "Secret")]
        [ValidateNotNullOrWhiteSpace()]
        [string[]]$Secret,

        [Parameter()]
        [ValidateNotNullOrWhiteSpace()]
        [string]$Path = "/",

        [Parameter()]
        [ValidateNotNullOrWhiteSpace()]
        [string]$Environment,

        [Parameter()]
        [switch]$AsHashtable
    )

    begin {
        Test-VaultBinaries
        
        [string[]]$stdStream = @()
        [string[]]$errStream = @()
        [string[]]$params = @()
       #[Hashtable]$splat = @{}

        [object]$output = $null
    }

    process {
        foreach ($item in $Vault) {
            try {
                if (-not (Test-Vault -Vault $item)) {
                    throw "Vault not connected."
                }

                $params = @(
                    "secrets"
                )

                if (-not [string]::IsNullOrWhiteSpace($Secret)) {
                    $params += @(
                        "get", $Secret
                    )
                }
                else  {
                    # nop
                }

                if (-not [string]::IsNullOrWhiteSpace($Environment)) {
                    $params += @(
                        "--env", $Environment
                    )
                }
                else {
                    $params += @(
                        "--env", $item.Environment
                    )
                }

                $params += @(
                    "--domain",    $item.Domain.AbsoluteUri
                    "--projectId", $item.Project.Guid
                    "--path",      $Path
                    "--telemetry=false"
                )

                if ($AsHashtable.IsPresent) {
                    $params += "--output=json"
                }
                else {
                    $params += "--plain"
                }

                $stdStream = ($item.Token | ConvertFrom-SecureString -AsPlainText) | infisical @params 2> Variable:errStream
                if ($LASTEXITCODE -ne 0) {
                    throw ($errStream -join [Environment]::NewLine)
                }

                if ($AsHashtable.IsPresent) {
                    [Hashtable]$output = [Ordered]@{}
                    foreach ($result in ($stdStream | ConvertFrom-Json -Depth 9 -AsHashtable)) {
                        try {
                            $output.$($result.secretKey) = $result.secretValue | ConvertFrom-Json -Depth 9 -AsHashtable
                        }
                        catch {
                            $output.$($result.secretKey) = $result.secretValue
                        }
                    }
                }
                else {
                    [string[]]$output = $stdStream
                }

                Write-Output -InputObject $output

                continue
            }
            catch {
                Write-Error -Message $PSItem.Exception.Message
            }
            finally {
                # nop
            }
        }
    }

    end {
        # nop
    }

    clean {
        # nop
    }
}
