function New-VaultInfisical {
    [CmdletBinding(DefaultParameterSetName = "Credential")]
    [OutputType("VaultInfisical")]

    param (
        [Parameter(Mandatory, ParameterSetName = "Credential")]
        [ValidateNotNull()]
        [PSCredential]$Credential,

        [Parameter(Mandatory, ParameterSetName = "Token")]
        [ValidateNotNull()]
        [SecureString]$Token,

        [Parameter()]
        [ValidateNotNull()]
        [Uri]$Domain = "https://eu.infisical.com",

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [Guid]$Organization,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [Guid]$Project,

        [Parameter()]
        [ValidateNotNullOrWhiteSpace()]
        [string]$Path = (Join-Path -Path "/" -ChildPath @()),

        [Parameter()]
        [ValidateSet("dev", "staging", "prod")]
        [string]$Environment = "dev"
    )

    begin {
        [PSCustomObject]$vault = $null

        Set-Item -Path "Env:INFISICAL_DISABLE_UPDATE_CHECK" -Value "true" -Force
    }

    process {
        $vault = [PSCustomObject]@{
            PSTypeName     = "VaultInfisical"
            "Credential"   = ([PSCredential]$Credential)
            "Domain"       = ([Uri]$Domain)
            "Organization" = ([Guid]$Organization)
            "Project"      = ([Guid]$Project)
            "Path"         = ([string]$Path)
            "Environment"  = ([string] $Environment)
            "Token"        = ([SecureString]$Token)
        }

        $vault | Add-Member -MemberType 'ScriptMethod' -Name "Login" -Value {
            $params = @(
                "login"
                "--domain",          $this.Domain.AbsoluteUri
                "--email",           $this.Credential.UserName
                "--password",        $this.Credential.Password | ConvertFrom-SecureString -AsPlainText
                "--organization-id", $this.Organization.Guid
                "--telemetry=false"
                "--plain"
                "--silent"
            )
            $this.Token = (infisical @params 2> Variable:errStream) | ConvertTo-SecureString -AsPlainText
            if ($LASTEXITCODE -ne 0) {
                Write-Error -Message ($errStream -join [Environment]::NewLine)
            }
        }
        $vault | Add-Member -MemberType ScriptMethod -Name "Logout" -Value {
            $this.Token = [SecureString]::New()
    
            if (Test-Path -Path $this.GetTokenFile()) {
                Remove-Item -Path $this.GetTokenFile() -Force
            }
        }
        $vault | Add-Member -MemberType ScriptMethod -Name "StartConnection" -Value {
            if ($null -eq $this.Token) {
                Write-Error -Message "No valid token found." -ErrorAction 'Stop'
            }
            Set-Item -Path "Env:INFISICAL_TOKEN" -Value ($this.Token | ConvertFrom-SecureString -AsPlainText)
        }
        $vault | Add-Member -MemberType ScriptMethod -Name "StopConnection" -Value {
            Remove-Item -Path "Env:INFISICAL_TOKEN" -Force -ErrorAction 'SilentlyContinue'
        }
        $vault | Add-Member -MemberType ScriptProperty -Name "Status" -Value {
            $params = @(
                "login"
                "status"
                "--domain", $this.Domain.AbsoluteUri
                "--telemetry=false"
            )
            $this.StartConnection()
            try {
                $null = infisical @params 2> Variable:errStream
                if ($LASTEXITCODE -ne 0) {
                    Write-Debug -Message ($errStream -join [Environment]::NewLine)
                    return $false
                }
                return $true
            }
            finally {
                $this.StopConnection()
            }
        }
        $vault | Add-Member -MemberType ScriptMethod -Name "GetCredentialPath" -Value {
            return [IO.FileInfo]::new((Join-Path -Path $PWD.Path -ChildPath @(".config", "infisical")))
        }
        $vault | Add-Member -MemberType ScriptMethod -Name "SaveCredential" -Value {
            if ($null -eq $this.Token) {
                Write-Debug -Message "No token available."
                return
            }
    
            if (-not (Test-Path -Path $this.GetTokenFile().Directory)) {
                New-Item -Path $this.GetTokenFile() -ItemType 'Directory' -Force | Out-Null
            }
            $this.Token | ConvertFrom-SecureString -AsPlainText | Set-Content -Path $this.GetTokenFile() -Force
        }
        $vault | Add-Member -MemberType ScriptMethod -Name "RestoreCredential" -Value {
            $credentialFile = $this.GetTokenFile()
            if (-not (Test-Path -Path $credentialFile)) {
                return
            }
            $this.Token = Get-Content -Path $credentialFile | ConvertTo-SecureString -AsPlainText
        }

        Write-Output -InputObject $vault
    }

    end {

    }

    clean {
        
    }
}