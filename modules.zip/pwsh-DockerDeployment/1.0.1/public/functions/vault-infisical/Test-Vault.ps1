function Test-Vault {
    [CmdletBinding()]
    [OutputType([bool])]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [PSTypeName("VaultInfisical")]
        [PSCustomObject[]]$Vault
    )

    begin {
        Test-VaultBinaries

        [string[]]$stdStream = @()
        [string[]]$errStream = @()
        [string[]]$params = @()
       #[hashtable]$splat = @{}
    }

    process {
        foreach ($item in $Vault) {
            try {
                if ($null -eq $item.Token) {
                    throw "No token present for vault."
                }
                else {
                    $params = @(
                        "login"
                        "status"    
                        "--domain", $item.Domain.AbsoluteUri
                        "--telemetry=false"
                    )

                    $stdStream = ($item.Token | ConvertFrom-SecureString -AsPlainText) | infisical @params 2> Variable:errStream
                    if ($LASTEXITCODE -ne 0) {
                        throw ($errStream -join [Environment]::NewLine)
                    }
                }

                Write-Output -InputObject $true

                continue
            }
            catch {
                Write-Debug -Message $PSItem.Exception.Message

                Write-Output -InputObject $false

                continue
            }
            finally {
                # nop
            }
        }
    }

    end {
        # nop
    }

    clean {
        # nop
    }
}