function Test-Vault {
    [CmdletBinding()]
    [OutputType([bool])]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [pscustomobject[]]$Vault
    )

    begin {
        [string[]]$stdStream = @()
        [string[]]$errStream = @()
        [string[]]$params = @()
    }

    process {
        foreach ($item in $Vault) {
            if ($null -eq $item.Token) {
                Write-Verbose -Message "Empty token property."
                return $false
            }
    
            Set-Item -Path "Env:INFISICAL_TOKEN" -Value ($item.Token | ConvertFrom-SecureString -AsPlainText)
            $params = @(
                "login"
                "status"    
                "--domain", $item.Domain.ToString()
                "--telemetry=false"
            )
            $stdStream = infisical @params 2> Variable:errStream
            if ($LASTEXITCODE -ne 0) {
                Write-Error -Message ($errStream -join [Environment]::NewLine)
                return $false
            }
            else {
                return $true
            }
        }
    }

    end {

    }

    clean {
        Remove-Item -Path "Env:INFISICAL_TOKEN" -Force -ErrorAction 'SilentlyContinue'
    }
}