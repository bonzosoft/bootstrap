function Test-VaultBinaries {
    [CmdletBinding()]
    [OutputType([bool])]

    param (
        # nop
    )

    if (-not (Get-Command -Name "infisical" -ErrorAction 'SilentlyContinue')) {
        throw "Command 'infisical' not found. Please install 'infisical' package."
    }

    return $true
}