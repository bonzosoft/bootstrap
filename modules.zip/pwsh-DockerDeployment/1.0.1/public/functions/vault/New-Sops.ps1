function New-Sops {

    [CmdletBinding()]
    [OutputType([PSCustomObject])]

    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNull()]
        [IO.FileInfo[]]$Path,

        [Parameter()]
        [ValidateNotNull()]
        [Hashtable]$Value = $null,

        [Parameter()]
        [ValidateNotNull()]
        [Hashtable]$KDF = $null
    )

    begin {
        [PSCustomObject]$data = $null
    }

    process {
        foreach ($item in $Path) {
            $data = [PSCustomObject]@{
                "Path" = [IO.FileInfo]$item
                "KDF"  = [Hashtable]$null
                "Data" = [Hashtable]$Value
            }
            $data | Add-Member -MemberType 'ScriptMethod' -Name "ReadData" -Value {
                if ($null -eq $this.Path) {
                    throw "Path must not be null."
                }
                $data = $this.Path | Get-Content | ConvertFrom-Json -Depth 9 -AsHashtable

                if ($data.Keys -contains "KDF") {
                    $this.KDF = $data.KDF
                    $data.Remove("KDF")
                }
                $this.Data = $data
            }
            $data | Add-Member -MemberType 'ScriptMethod' -Name "WriteData" -Value {
                if ($null -eq $this.Path) {
                    throw "Path must not be null."
                }
                [hashtable]$data = @{}
                $data = $this.Data
                Write-Output $data
                Write-Output $this.PSObject.Properties.Name
                if ($this.PSObject.Properties.Name -contains "KDF") {
                    if ($null -ne $this.KDF) {
                        $data += $this.KDF
                    }
                }
                Write-Output $data
                $data | ConvertTo-Json -Depth 9 | Set-Content -Path $this.Path -Force
            }
            $data | Add-Member -MemberType 'ScriptMethod' -Name "New-Hash" -Value {

            }
            $data | Add-Member -MemberType 'ScriptMethod' -Name "SetKDF" -Value {
                param (
                    [SecureString]$Password
                )

                New-Hash

            }
            $data | Add-Member -MemberType 'ScriptMethod' -Name "GetKDF" -Value {

            }
            
            $data | Add-Member -MemberType 'ScriptMethod' -Name "EncryptValue" -Value {
                param(
                    [SecureString]$Password, 
                    [string[]]$Key
                )

                foreach ($itemKey in $Key) {
                    $snapshot = $this.Data.Keys.Clone()
                    foreach ($item in $snapshot) {
                        if ($item -match $Key) {
                            $argon2id = $Password | New-HashArgon2id

                            $argon2id.Salt
                            $argon2id.Hash
                            $argon2id.Length

                            $this.Data.$item = "[ENC:" + ($this.Data.$item | ConvertTo-SecureString -AsPlainText | ConvertFrom-SecureString -Key $argon2id.GetHashBytes()) + "]"
                        }
                    }
                }
            }

            <#
            $data | Add-Member -MemberType 'ScriptMethod' -Name "EncryptData" -Value {
                param([PSCustomObject]$Argon2id, [string[]]$Keys = $null)

                if ($null -eq $Argon2id) {
                    throw "Object must not be empty."
                }

                if (-not [string]::ValidateNotNullOrWhiteSpace($Argon2id.Hash)) {
                    throw "Hash must not be empty or whitespace."
                }
                

                if ($null -eq $Keys) {
                    foreach ($item in $this.Data.Keys) {
                        if $($item -match $Keys) {
                            $
                        }
                    }
                }
                else {

                }


            }
            #>
            

            Write-Output -InputObject $data
        }
    }

    end {

    }

    clean {

    }
}

$sops = New-Sops -Path "./prueba" -Value ([hashtable]@{"valor1"= "hola"; "valor2"= "adios"})

$password = ("password" | ConvertTo-SecureString -AsPlainText)


$sops.EncryptValue($password, "valor*")
$sops.WriteData()
cat ./prueba