enum VaultStatus {
    Unknown = 0
    Unlocked
    Locked
    Unauthenticated
}