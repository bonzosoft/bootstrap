[IO.FileInfo]$PSCommandFile = Get-Item -Path $PSCommandPath


Write-Verbose -Message "Loading module '$($PSCommandFile.BaseName)'."


### Public variables ###########################################################
[Management.Automation.OrderedHashtable]$Script:Context = [ordered]@{}


# export public variables
Export-ModuleMember -Variable *


### Private variables ##########################################################
# nop


### List of required modules ###################################################
[string[]]$requiredModules = @(
    "powershell-yaml"
    "pwsh-dotenv"
)

foreach ($module in $requiredModules) {
    Write-Verbose -Message "Loading submodule '$module'."
    Import-Module -Name (Join-Path -Path $PSCommandFile.DirectoryName -ChildPath @("etc", $module)) -Force
}


### List of requried binaries ##################################################
[string[]]$requiredBinaries = @(
    # nop
)

foreach ($binary in $requiredBinaries) {
    Write-Verbose -Message "Loading binary '$binary'."
    Add-Type -Path (Join-Path -Path $PSCommandFile.DirectoryName -ChildPath @("bin", $binary))
}


### Load module assets #########################################################

# Get public asset definition files
[IO.FileInfo[]]$publicVariables = Get-ChildItem -Path (Join-Path -Path $PSCommandFile.DirectoryName -ChildPath @("public", "variables", "*.ps1")) -Recurse -ErrorAction SilentlyContinue
[IO.FileInfo[]]$publicFunctions = Get-ChildItem -Path (Join-Path -Path $PSCommandFile.DirectoryName -ChildPath @("public", "functions", "*.ps1")) -Recurse -ErrorAction SilentlyContinue
[IO.FileInfo[]]$publicClasses = Get-ChildItem -Path (Join-Path -Path $PSCommandFile.DirectoryName -ChildPath @("public", "classes", "*.ps1")) -Recurse -ErrorAction SilentlyContinue

# Get private asset definition files
[IO.FileInfo[]]$privateVariables = Get-ChildItem -Path (Join-Path -Path $PSCommandFile.DirectoryName -ChildPath @("private", "variables", "*.ps1")) -Recurse -ErrorAction SilentlyContinue
[IO.FileInfo[]]$privateFunctions = Get-ChildItem -Path (Join-Path -Path $PSCommandFile.DirectoryName -ChildPath @("private", "functions", "*.ps1")) -Recurse -ErrorAction SilentlyContinue
[IO.FileInfo[]]$privateClasses = Get-ChildItem -Path (Join-Path -Path $PSCommandFile.DirectoryName -ChildPath @("private", "classes", "*.ps1")) -Recurse -ErrorAction SilentlyContinue

# Dot source asset definition files
foreach ($file in ($publicVariables + $privateVariables + $publicFunctions + $privateFunctions + $publicClasses + $privateClasses)) {    
    Write-Verbose -Message "Loading asset '$($file.BaseName)'."
    . $file.FullName
}


### Export public module assets ################################################

# Export public variable
foreach ($file in $publicVariables) {
    Write-Verbose -Message "Exporting public variable '$($file.BaseName)'."
    Export-ModuleMember -Variable $file.BaseName
}

# Export public function
foreach ($file in $publicFunctions) {
    Write-Verbose -Message "Exporting public function '$($file.BaseName)'."
    Export-ModuleMember -Function $file.BaseName
}

# Export public class
foreach ($file in $publicClasses) {
    Write-Verbose -Message "Exporting public class '$($file.BaseName)'."
    [Type]$type = [Type]$file.BaseName
    [PSObject]$typeAccelerator = [PSObject].Assembly.GetType("System.Management.Automation.TypeAccelerators")
    $typeAccelerator::Remove($type.FullName)
    $typeAccelerator::Add($type.FullName, $type)
    $MyInvocation.MyCommand.ScriptBlock.Module.OnRemove = {$typeAccelerator::Remove($type.FullName)} | Out-Null
}


Write-Verbose -Message "Loaded module '$($PSCommandFile.BaseName)'."
