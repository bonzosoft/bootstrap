function Write-GitConfig {
    [CmdletBinding()]
    [OutputType([void])]

    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [IO.FileInfo]$Path,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [hashtable]$Value
    )

    begin {

    }

    process {
        if (-not (Test-Path -Path $Path.Directory)) {
            New-Item -Path $Path.Directory -ItemType 'Directory' -Force
        }
        Set-Content -Path $Path -Value ($Value | ConvertTo-Json)
    }

    end {

    }

}